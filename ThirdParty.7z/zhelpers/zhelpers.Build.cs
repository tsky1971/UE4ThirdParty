// Fill out your copyright notice in the Description page of Project Settings.

using System.IO;
using UnrealBuildTool;

public class zhelpers : ModuleRules
{
	public zhelpers(ReadOnlyTargetRules Target)
	{
		Type = ModuleType.External;
		string projectRoot = ("../../../../../../../");
		
		string includePath = Path.Combine(ModuleDirectory, projectRoot, "include", "zhelpers");
        PublicIncludePaths.AddRange(new string[] { includePath });

        if (Target.Platform == UnrealTargetPlatform.Win64)
		{
            // Add the import library
            
		}
        else if (Target.Platform == UnrealTargetPlatform.Mac)
        {
            
        }
	}
}
